
import { router, routerIn } from "./app/js/routes.js";
import { eventsCont } from "./app/views/eventsView.js";

const page = window.location.hash.slice(1)

router()

// Evento para cambiar de ruta al cambiar el hash
window.addEventListener("hashchange", router);

// También ejecuta el router al cargar la página
window.addEventListener("load", router);

// Check login with email or username
if (page == '/dashboard') {
    eventsCont()
}