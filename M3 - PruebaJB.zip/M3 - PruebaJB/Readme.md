/mi-proyecto │ 
             ├── index.html 
             ├── README.md 
             ├── db.json 
             │ 
             ├── /css 
             │     └── style.css 
             │ 
             ├── /js 
             │ 
             ├── main.js 
             │      └── routes.js 
             │ 
             ├── /views 
             │ 
             ├── home.html 
             │ 
             ├── about.html 
             │ 
             └── 404.html


##  Comenzar

### 1. Instalar dependencias

```bash
npm install
```

### 2. Levantar el servidor de desarrollo

```bash
npm run dev
```