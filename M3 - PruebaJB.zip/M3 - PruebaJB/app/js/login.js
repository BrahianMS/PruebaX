// Check login with email or username
export async function logIn(email, password) {
    try {
        const response = await fetch(`http://localhost:3000/users?email=${email}`);
        let user = await response.json();

        if (user.length === 0) {
            return { error: 'The email or username does not exist' };
        }

        if (user[0].password !== password) {
            return { error: 'Incorrect password' };
        }

        return { success: 'Successful login', user: user[0] };

    } catch (error) {
        console.log('Login failed:', error);
        return { error: 'There was a problem trying to log in.' };
    }
}
