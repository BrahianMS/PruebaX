// Check login with email or username
export async function logIn(email, password) {
    try {
        const response = await fetch(`http://localhost:3000/users?email=${email}`);
        let user = await response.json();

        if (user.length === 0) {
            return { error: 'The email or username does not exist' };
        }

        if (user[0].password !== password) {
            return { error: 'Incorrect password' };
        }

        return { success: 'Successful login', user: user[0] };

    } catch (error) {
        console.log('Login failed:', error);
        return { error: 'There was a problem trying to log in.' };
    }
}

// Handle login form submission
document.getElementById('loginForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('pword').value;

    const resultado = await logIn(email, password);

    if (resultado.error) {
        alert(resultado.error);
    } else {
        alert(resultado.success);
        let user = resultado.user;
        let inf = { 'id': user.id, 'name': user.name, 'email': user.email, 'userName': user.userName};
        sessionStorage.setItem('user', JSON.stringify(inf));
        sessionStorage.setItem('Auth', 'true');
        window.location.href = '../pages/notesManagement.html';
    }
});