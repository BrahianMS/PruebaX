export function dashboard() {
    const main = document.getElementById("main");
    main.innerHTML =`<div class="dashboard w-100 h-100 row">
                        <div class="col-md-2 d-flex flex-column gap-5 pt-5 align-items-center bg-dark">
                            <h4 class="text-light">Eventos</h4>
                            <div class="row g-0 m-2">
                                <div class="col-md-4">
                                <img src="https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg" class="img-fluid rounded-circle" alt="avatar">
                                </div>
                                <div class="col-md-8">
                                <div class="card-body pt-2 ps-3">
                                    <h5 class="card-title text-light" id="userName">UserName</h5>
                                    <p class="card-text text-light" id="userRole">User role</p>
                                </div>
                                </div>
                            </div>
                            <nav class="">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" id="events" aria-current="page" href="#">Events</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="enroll" href="#">Enrollment</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Log-out</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        <main class="col-md-9 m-5" id="eventContent">
                            <table class="table">
                                <thead>
                                    <tr>
                                    <th scope="col">Nombre</th>
                                    <th scope="col">Descripción</th>
                                    <th scope="col">Capacidad</th>
                                    <th scope="col">Fecha</th>
                                    <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="tableBody">
                                    
                                </tbody>
                            </table>
                        </main>
                    </div>`;
    
    const user = JSON.parse(sessionStorage.getItem('user'))
    
    const name = document.getElementById("userName");
    const role = document.getElementById('userRole')
    name.innerHTML = user.name
    role.innerHTML = user.role
    const events = document.getElementById("events");
    const enroll = document.getElementById("entoll")

    events.addEventListener('click', (e) => {
        e.preventDefault();

        eventsCont(user.role)}
    )
}


async function eventsCont(role) {
    const tbody = document.getElementById('tableBody');
    try {
        let res = await fetch('http://localhost:3000/events');
        let events = await res.json();
        console.log(events);
        
        tbody.innerHTML = ""
        if (role == 'admin') {
        events.forEach(event => {
        tbody.innerHTML += `<tr>
                                <th scope="row">${event.name}</th>
                                <td>${event.desc}</td>
                                <td>${event.capacity}</td>
                                <td>${event.date}</td>
                                <td><button class="btn btn-warning edit" data-id="${event.id}">Edit</button>
                                <button class="btn btn-danger del" data-id="${event.id}">Delete</button></td>
                            </tr>
                            `
        })
    }

    if (role == 'user') {
        events.forEach(event => {
        tbody.innerHTML += `<tr>
                                <th scope="row">${event.name}</th>
                                <td>${event.desc}</td>
                                <td>${event.capacity}</td>
                                <td>${event.date}</td>
                                <td><button class="btn btn-primary join" data-id="${event.id}">Join</button></td>
                            </tr>
                            `
        })
    }
    }
    catch (error) {
        console.log('Error:', error)
    }
    
        
};