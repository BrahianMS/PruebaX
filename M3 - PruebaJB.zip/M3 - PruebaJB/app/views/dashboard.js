export function dashboard() {
    const dashboard = `<div class="dashboard w-100 h-100 row">
                            <div class="col-md-2 d-flex flex-column justify-content-center  align-items-center">
                                <h4>Eventos</h4>
                                <div class="row g-0 m-2">
                                    <div class="col-md-4">
                                    <img src="./index.html#/login./assets/img/avatar.jpg" class="img-fluid rounded-circle" alt="avatar">
                                    </div>
                                    <div class="col-md-8">
                                    <div class="card-body pt-2 ps-3">
                                        <h5 class="card-title">UserName</h5>
                                        <p class="card-text">User role</p>
                                    </div>
                                    </div>
                                </div>
                                <nav class="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" aria-current="page" href="#/event">Events</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#/dashboard/enrollments">Enrollment</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#/landing">Log-out</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                            <main class="col-md-10" id="eventContent">
                                <table class="table">
                        <thead>
                            <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">Descripción</th>
                            <th scope="col">Capacidad</th>
                            <th scope="col">Fecha</th>
                            </tr>
                        </thead>
                        <tbody id="tableBody">
                            
                        </tbody>
                    </table>
                            </main>
                        </div>`
    return dashboard

}