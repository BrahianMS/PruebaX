export function eventsView() {
    const events = `<table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Nombre</th>
                                <th scope="col">Descripción</th>
                                <th scope="col">Capacidad</th>
                                <th scope="col">Fecha</th>
                            </tr>
                        </thead>
                        <tbody id="tableBody">
                            <tr>
                                <th scope="row">1</th>
                                <td>Mark</td>
                                <td>Otto</td>
                                <td>@mdo</td>
                            </tr>
                            <tr>
                                <th scope="row">2</th>
                                <td>Jacob</td>
                                <td>Thornton</td>
                                <td>@fat</td>
                            </tr>
                            <tr>
                                <th scope="row">3</th>
                                <td>John</td>
                                <td>Doe</td>
                                <td>@social</td>
                            </tr>
                        </tbody>
                    </table>`

    return events
}

export async function eventsCont() {
    const tbody = document.getElementById('tableBody');
    try {
        let res = await fetch('http://localhost:3000/events');
        let events = await res.json();

        events.forEach(event => {
        tbody.innerHTML += `<tr>
                            <th scope="row">${event.name}</th>
                            <td>${event.desc}/td>
                            <td>${event.capacity}</td>
                            <td>${event.date}</td>
                        </tr>`
        })
    }
    catch (error) {
        console.log('Error:', error)
    }
    
        
    };