export function notFound() {
    const cont = `<h1>404</h1><p>Página no encontrada.</p>`
    return cont
}