export function registerView() {
    const cont = `<div class="container d-flex justify-content-center align-items-center mt-5">
                    <div class="col-md-4">
                        <h2 class="fw-bold mb-4">Create your account</h2>
                        <form id="registerForm">
                            <div class="mb-3">
                            <label for="name" class="form-label">Full Name</label>
                            <input type="text" id="name" class="form-control form-control-lg" placeholder="Enter your full name" required>
                            </div>
                            <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" id="email" class="form-control form-control-lg" placeholder="Enter your email" required>
                            </div>
                            <div class="mb-4">
                            <label for="pword" class="form-label">Password</label>
                            <input type="password" id="pword" class="form-control form-control-lg" placeholder="Create a password" required>
                            </div>
                            <div class="mb-4">
                            <label for="pword" class="form-label">Password</label>
                            <input type="password" id="pword1" class="form-control form-control-lg" placeholder="Create a password" required>
                            </div>
                            <div class="d-grid mb-3">
                            <button type="submit" class="btn btn-primary btn-lg" id="register">Register</button>
                            </div>
                            <div class="text-center">
                            <small class="text-muted">Already have an account? <a href="./index.html#/login" class="text-decoration-none">Sign in</a></small>
                            </div>
                        </form>
                    </div>
                </div>`

    return cont
}