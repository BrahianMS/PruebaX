export function loginView() {
    const cont = `<div class="container d-flex flex-column justify-content-center align-items-center">
            <div class="card col-md-4">
            <h2 class="text-center fw-bold mb-4">Welcome</h2>
                <div class="card-body">
                    <form id="loginForm">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" aria-describedby="emailHelp">
                        </div>
                        <div class="mb-3">
                            <label for="pword" class="form-label">Password</label>
                            <input type="password" class="form-control" id="pword">
                        </div>
                        <button type="submit" class="btn primary w-100" id="saveLog">Log in</button>
                    </form>
                </div>
            </div>
        </div>`
    
    return cont
}

